//Adar Mak 84387
package application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class AnimalController {
    @Autowired
    private AnimalService animalService;

    
    //Alle Animal abrufen
    @GetMapping("/animals") 
    public List<Animal> getAllAnimals() {
        return animalService.findAllAnimal();
    }

    
    //Animal erstellen
    @PostMapping("/animals") 
    public Animal createAnimal(@RequestBody Animal animal) {
        return animalService.saveAnimal(animal);
    }

    
    //Animal aktualisieren richtig
    /*@RequestMapping(method=RequestMethod.PUT, value="/animals/{id}")
	public void updateAnimal(@PathVariable Long id, @RequestBody Animal animal) {
	animalService.updateAnimal(id, animal);
    }*/
    
    //Animal aktualisieren (pfusch)
    @RequestMapping(method=RequestMethod.PUT, value="/animals/{id}")
	public void updateAnimal(@RequestBody Animal animal) {
	animalService.updateAnimal(animal);
    }

    
    //Animal löschen
    @RequestMapping(method=RequestMethod.DELETE, value="/animals/{id}") 
	public void deleteAnimal(@PathVariable Long id, @RequestBody Animal animal) {
		animalService.deleteAnimal(id, animal); 
	}
}
